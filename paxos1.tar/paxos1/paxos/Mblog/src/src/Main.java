import java.io.IOException;


public class Main {

	public static void main(String[] args)  throws IOException{
		Replica replica = new Replica("logfile.txt","configuration/config.txt" );
	}

}
